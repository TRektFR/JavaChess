package projet.piece;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/**
		 * @author DEFREITAS Alexandre
		 * @author MALO Amandine
		 * @author BONNET Melanie
		 * @author GOMES DA FONSECA Bruno
		 */	
		
		Partie game = new Partie();
		
		game.gestionPartie();
	}
}
